#!/bin/bash
rm -rf RMSD_* topol.tpr md.log colvar_* bck.* traj.xtc *.cpt *.gplt ener.edr   mdout.mdp  newmd.mdp HILLS \#* COLVAR colvar confout.gro *.xtc 
